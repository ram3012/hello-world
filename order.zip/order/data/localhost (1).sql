-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 20, 2017 at 07:49 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ordermanagement`
--
CREATE DATABASE `ordermanagement` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ordermanagement`;

-- --------------------------------------------------------

--
-- Table structure for table `order_entity`
--

CREATE TABLE IF NOT EXISTS `order_entity` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `order_entity`
--

INSERT INTO `order_entity` (`id`, `email_id`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'test@gmail.com', 2, 1, '2017-06-19 00:00:00', '0000-00-00 00:00:00'),
(2, 'test@gmail.com', 2, 1, '2017-06-19 00:00:00', '0000-00-00 00:00:00'),
(3, 'test@gmail.com', 3, 1, '2017-06-19 00:00:00', '0000-00-00 00:00:00'),
(4, 'test@gmail.com', 2, 1, '2017-06-19 00:00:00', '0000-00-00 00:00:00'),
(5, 'user1', 3, 1, '2017-06-20 00:00:00', '0000-00-00 00:00:00'),
(6, 'user1', 3, 1, '2017-06-20 00:00:00', '0000-00-00 00:00:00'),
(7, 'user1', 3, 1, '2017-06-20 00:00:00', '0000-00-00 00:00:00'),
(8, 'user1', 3, 1, '2017-06-20 00:00:00', '0000-00-00 00:00:00'),
(9, 'user1', 3, 1, '2017-06-20 00:00:00', '0000-00-00 00:00:00'),
(10, 'user1', 3, 1, '2017-06-20 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_entity_items`
--

CREATE TABLE IF NOT EXISTS `order_entity_items` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `order_entity_items`
--

INSERT INTO `order_entity_items` (`id`, `order_id`, `name`, `user_id`, `price`, `quantity`, `created_at`, `updated_at`) VALUES
(3, 3, 'test', 2, 21, 32, '2017-06-19 00:00:00', '2017-06-20 00:00:00'),
(4, 4, 'lk', 2, 454, 54, '2017-06-19 00:00:00', '0000-00-00 00:00:00'),
(6, 6, 'testt', 3, 23, 23, '2017-06-20 00:00:00', '2017-06-20 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(320) CHARACTER SET utf8 NOT NULL,
  `Password` text CHARACTER SET utf8 NOT NULL,
  `name` varchar(255) NOT NULL,
  `Status` varchar(1) NOT NULL DEFAULT '0',
  `CreatedDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EmailChangeCode` varchar(320) CHARACTER SET utf8 NOT NULL,
  `Salt` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Email`, `Password`, `name`, `Status`, `CreatedDateTime`, `EmailChangeCode`, `Salt`) VALUES
(2, 'user', 'adYvUz9YgL7uE', 'ramkumar', '0', '2017-04-19 02:16:27', '', '$2y$10$849ed19ab1bd694eb8f6752a676bab450b572ea07273'),
(3, 'user1', 'adYvUz9YgL7uE', 'rajaram', '0', '2017-06-20 13:54:54', '', '$2y$10$849ed19ab1bd694eb8f6752a676bab450b572ea07273');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
