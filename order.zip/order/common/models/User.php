<?php

/*

  Created By   	: 	Karthikeyan K

  Created Date	:   25-Aug-2016

  Modified By		:	Karthikeyan K

  Modified Date	:	22-Sep-2016 

 */

/**
 
 *
  
 * @property integer $ID
 * @property string $Email
 * @property string $Password
 * @property string $DisplayName
 * @property string $ProfileImage
 * @property integer $Status
 * @property string $CreatedDateTime
 * @property integer $CreatedBy
 * @property integer $Deletedby
 * @property string $DeletedDateTime
 * @property integer $ModifiedBy
 * @property string $ModifiedDateTime
 * @property integer $IsDeleted
 * @property string $EmailChangeCode
 */
class User extends CActiveRecord { 

    public $newpasswod;
    public $confirmpasswod;

    /**
     * Returns the static model of the specified AR class.
     * @param string $className active record class name.
     * @return AdminUser the static model class
     */
    public static function model($className = __CLASS__) {
        return parent::model($className);
    }

    /**
     * @return string the associated database table name
     */
    public function tableName() {
        return 'user'; 
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules() {
        // NOTE: you should only define rules for those attributes that
        // will receive user inputs.
        return array(
            array('Password,newpasswod,confirmpasswod', 'required', 'on' => 'update'),
            array('confirmpasswod', 'compare', 'compareAttribute' => 'newpasswod', 'on' => 'update'),
            array('Password,newpasswod,confirmpasswod', 'length', 'min' => 8, 'max' => 100, 'on' => 'update'),
            array('Email', 'required', 'on' => 'changeemail'),
            array('Status, CreatedBy, Deletedby, ModifiedBy, IsDeleted', 'numerical', 'integerOnly' => true),
            array('Email', 'length', 'max' => 320),
            array('Password, DisplayName', 'length', 'max' => 100),
            array('EmailChangeCode', 'length', 'max' => 320),
            array('DeletedDateTime, ModifiedDateTime,newpasswod,confirmpasswod,Salt,name', 'safe'), 
            // The following rule is used by search().
            // Please remove those attributes that should not be searched.
            array('ID, Email, Password, DisplayName, ProfileImage, Status, CreatedDateTime, CreatedBy, Deletedby, DeletedDateTime, ModifiedBy, ModifiedDateTime, IsDeleted, EmailChangeCode,name', 'safe', 'on' => 'search'), 
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations() {
        // NOTE: you may need to adjust the relation name and the related
        // class name for the relations automatically generated below.
        return array(
        );
    }

    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels() {
        return array(
            'ID' => 'ID',
            'Email' => 'User Name',
            'Password' => 'Old Password',
            'DisplayName' => 'Display Name',
            'ProfileImage' => 'Profile Image',
            'Status' => 'Status',
            'CreatedDateTime' => 'Created date Time',
            'CreatedBy' => 'Created By',
            'Deletedby' => 'Deletedby',
            'DeletedDateTime' => 'Deleted Date Time',
            'ModifiedBy' => 'Modified By',
            'ModifiedDateTime' => 'Modified Date Time',
            'IsDeleted' => 'Is Deleted',
            'EmailChangeCode' => 'Email Change Code',
            'newpasswod' => 'New Password',
            'confirmpasswod' => 'Confirm Password',
        );
    }

    /**
     * Retrieves a list of models based on the current search/filter conditions.
     * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
     */
    public function search() {
        // Warning: Please modify the following code to remove attributes that
        // should not be searched.

        $criteria = new CDbCriteria;

        $criteria->compare('ID', $this->ID);
        $criteria->compare('Email', $this->Email, true);
        $criteria->compare('Password', $this->Password, true);
        $criteria->compare('DisplayName', $this->DisplayName, true);
        $criteria->compare('ProfileImage', $this->ProfileImage, true);
        $criteria->compare('Status', $this->Status);
        $criteria->compare('CreatedDateTime', $this->CreatedDateTime, true);
        $criteria->compare('CreatedBy', $this->CreatedBy);
        $criteria->compare('Deletedby', $this->Deletedby);
        $criteria->compare('DeletedDateTime', $this->DeletedDateTime, true);
        $criteria->compare('ModifiedBy', $this->ModifiedBy);
        $criteria->compare('ModifiedDateTime', $this->ModifiedDateTime, true);
        $criteria->compare('IsDeleted', $this->IsDeleted);
        $criteria->compare('EmailChangeCode', $this->EmailChangeCode, true);

        return new CActiveDataProvider($this, array(
            'criteria' => $criteria,
        ));
    }

}
