<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProActiveRecord
 *
 * @author arunmozhi
 */
class ProActiveRecord extends CActiveRecord {

    public static function model($class = __CLASS__) {
        return parent::model($class);
    }

    public function getStatus() {
        return array(
            array('status' => '1', 'status_title' => 'Active'),
            array('status' => '0', 'status_title' => 'In Active'),
        );
    }

    public function getStatusVal($status) {
        if ($status == 1)
            return 'Active';
        else
            return 'In Active';
    }

    public function getStatusDropdown($status, $id) {
        $stats = array(0 => 'In Active', 1 => 'Active');
        return CHtml::dropDownlist('UserStatus[user_status]', $status, $stats, array(
                    'class' => 'status',
                    'data-id' => $id,
                    //~ 'prompt' => '--Select Status--',
                    'onchange' => 'javascript:changestatus(this.value,' . $id . ')',
        ));
    }

}
